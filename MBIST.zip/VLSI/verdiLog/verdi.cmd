verdiSetActWin -dock widgetDock_<Decl._Tree>
simSetSimulator "-vcssv" -exec "simv" -args
debImport "-dbdir" "simv.daidir/"
verdiSetActWin -dock widgetDock_MTB_SOURCE_TAB_1
verdiWindowResize -win $_Verdi_1 "296" "114" "900" "700"
srcHBSelect "tb_decoder" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBSelect "tb_bist" -win $_nTrace1
srcHBSelect "tb_bist" -win $_nTrace1
srcTBInvokeSim
verdiSetActWin -win $_InteractiveConsole_2
verdiSetActWin -dock widgetDock_<Member>
verdiSetActWin -win $_InteractiveConsole_2
srcHBSelect "tb_bist" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
wvCreateWindow
srcHBAddObjectToWave -clipboard
wvDrop -win $_nWave3
wvSelectGroup -win $_nWave3 {tb_bist}
wvSelectGroup -win $_nWave3 {tb_bist}
srcHBSelect "tb_multiplexer" -win $_nTrace1
verdiSetActWin -dock widgetDock_<Inst._Tree>
srcHBSelect "tb_decoder" -win $_nTrace1
srcHBSelect "tb_decoder" -win $_nTrace1
wvCreateWindow
wvSetPosition -win $_nWave4 {("G1" 0)}
wvOpenFile -win $_nWave4 {/home/ns6503/Documents/VLSI/inter.fsdb}
srcHBAddObjectToWave -clipboard
wvDrop -win $_nWave4
wvSetCursor -win $_nWave4 578.163772
