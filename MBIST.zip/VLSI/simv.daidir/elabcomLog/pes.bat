where
detach
quit
